using UnityEngine;

public class DestroyTrap : MonoBehaviour
{
    Rigidbody2D _rb;
    GameObject trap;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        trap = GameObject.Find("Trap");
        _rb = trap.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name.Equals("Trap"))
        {
            trap.SetActive(false);
        }
    }
}
