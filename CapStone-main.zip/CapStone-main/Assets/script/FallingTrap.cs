using UnityEngine;


public class FallingTrap : MonoBehaviour
{
    Rigidbody2D _rb;
    CircleCollider2D _cc;
    GameObject PlayerC;
    
    void Start()
    {
        _rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name.Equals("Player"))
        {
              _rb.isKinematic = false;
        }
         
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name.Equals("Player"))
        {
            PlayerC.GetComponent<PlayerController>().Dead();
        }
    }
 

  
    
}