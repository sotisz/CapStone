
using UnityEngine;

public class MoveBox : MonoBehaviour
{
    public float interactDistance = 1.5f;
    public KeyCode interactKey =  KeyCode.E;
    public LayerMask layerMask;
    
    public float pushForce = 5f;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(interactKey))
        {
            Collider2D target = Physics2D.OverlapCircle(transform.position, interactDistance, layerMask);
            if (target != null)
            {
                Plush(target.gameObject);
            }
        }
    }
    
    void Plush(GameObject target)
    {
        Rigidbody2D targetRB = target.GetComponent<Rigidbody2D>();
        if (targetRB != null)
        {
            targetRB.linearVelocity = new Vector2(pushForce, targetRB.linearVelocity.y);
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, interactDistance);
    }
}
